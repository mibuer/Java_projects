package app;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

public class Main {

	public static void main(String[] args) {
		
		StringBuilder builder = new StringBuilder();
		
		//Projekt with tasks
		Project project2 = new Project("Reading Book", LocalDate.of(2022, 1, 20), LocalDate.of(22, 1, 29));
		
		try {
			project2.addTask("Task1", LocalDateTime.now(), LocalDateTime.now().plus(5, ChronoUnit.MINUTES));
		} catch (TaskNotInProjectException e1) {
			System.err.println(e1.getMessage());
		}
		
		
		Task task2 = new Task("task2", 
				LocalDateTime.of(2022, 1, 21, 8, 30), LocalDateTime.of(2022, 1, 21, 12, 20));
		Task task3 = new Task("task3", 
				LocalDateTime.of(2022, 1, 22, 12, 30), LocalDateTime.of(2022, 1, 22, 18, 20));
		
		builder.append(task2);
		builder.append(task3);
		
		task2.addTimeWorked(Duration.of(30, ChronoUnit.MINUTES));
		task3.addTimeWorked(Duration.of(3, ChronoUnit.MINUTES));
		
		
		builder.ensureCapacity(200);
		
		
		
		System.out.println(builder.toString());
		System.out.println(task2.getTimeWorked().toMinutesPart());
		System.out.println(task3.getTimeWorked().toMinutesPart());
		
	}

}
