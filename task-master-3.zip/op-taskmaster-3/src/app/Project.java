package app;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Objects;

public class Project {
	
	private String name;
	private LocalDate startDate;
	private LocalDate endDate;
	
	//Task speichern
	ArrayList<Task> tasks = new ArrayList<Task>();
	
	//Konstruktor
	public Project(String name, LocalDate startDate, LocalDate endDate) {
		super();
		this.name = name;
		this.startDate = startDate;
		this.endDate = endDate;
	}
	
	//Task hinzuf�gen
	public void addTask(String name, LocalDateTime start, LocalDateTime end) throws TaskNotInProjectException {
		//Task nur hinzuf�grn, wenn start und end innerhalb Projektzeitraum sind
		//wenn Projekt am endDate bereits fertig sein muss, kann ich einfach endDate.startOfDay() verwenden
		//sonst braucht es komplexere Berechnung zB .plusDays(1)
		
		if(start.isAfter(this.startDate.atStartOfDay()) && end.isBefore(endDate.atStartOfDay().plusDays(1))) {
			tasks.add(new Task (name, start, end));
			return;
		} 
		//sonst wirf eine Exception
		throw new TaskNotInProjectException("Task start/end do not fit into project period");
		
	}
	
	//Getter/Setter f�r Tasks
	public ArrayList<Task> getTasks() {
		return tasks;
	}

	public void setTasks(ArrayList<Task> tasks) {
		this.tasks = tasks;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public LocalDate getStartDate() {
		return startDate;
	}

	public void setStartDate(LocalDate startDate) {
		this.startDate = startDate;
	}

	public LocalDate getEndDate() {
		return endDate;
	}

	public void setEndDate(LocalDate endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		//Eigene Formtierung des Datum
		String formattedStartDate = startDate.format(DateTimeFormatter.ofPattern(" E, dd.MM.yyyy-G-D")); //G -> n. Chr. D Day in Year
		
		return "Project [name=" + name + ", startDate=" + formattedStartDate + ", endDate=" + endDate + "]" + "\n";
	}

	@Override
	public int hashCode() {
		return Objects.hash(endDate, name, startDate);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Project other = (Project) obj;
		return Objects.equals(endDate, other.endDate) && Objects.equals(name, other.name)
				&& Objects.equals(startDate, other.startDate);
	}
	
	
	
	

}
