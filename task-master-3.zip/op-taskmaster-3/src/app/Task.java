package app;

import java.time.Duration;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Objects;

public class Task {
	
	private String name;
	private LocalDateTime start;
	private LocalDateTime end;
	private Duration timeWorked;  //verbrauchte Zeit f�r den Task
	
	
	//Konstruktor Task
	public Task(String name, LocalDateTime start, LocalDateTime end) {
		super();
		this.name = name;
		this.start = start;
		this.end = end;
		this.timeWorked = Duration.ZERO; //verbrauchte Zeit zum Task Start zur�cksetzen
	}
	
	//Arbeitszeit hinzuf�hen
	public void addTimeWorked(Duration duration) {
		//Duration-Objekte sind auch Immutable
		//timeWorked ver�ndert sich nicht!
		//timeWorked.add(duration);
		timeWorked = timeWorked.plus(duration);	
	}
	
	public Duration getTimeWorked() {
		return timeWorked;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public LocalDateTime getStart() {
		return start;
	}
	public void setStart(LocalDateTime start) {
		this.start = start;
	}
	public LocalDateTime getEnd() {
		return end;
	}
	public void setEnd(LocalDateTime end) {
		this.end = end;
	}
	
	@Override
	public String toString() {
		String formatter = start.format(DateTimeFormatter.ofPattern("dd.MM.yyyy, hh:mm"));
	
		return "Task [name=" + name + ", start=" + formatter + ", end=" + formatter + "]" + "\n";
	}
	
	@Override
	public int hashCode() {
		return Objects.hash(end, name, start);
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Task other = (Task) obj;
		return Objects.equals(end, other.end) && Objects.equals(name, other.name) && Objects.equals(start, other.start);
	}
	
	
	

}
