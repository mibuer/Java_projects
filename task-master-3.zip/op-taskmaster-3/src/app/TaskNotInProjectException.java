package app;

public class TaskNotInProjectException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public TaskNotInProjectException (String message) {
		super(message);
	}

	
	
	
	
}
