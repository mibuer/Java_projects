package at.wifiwien.javakurs.springboot_webservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootWebserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
