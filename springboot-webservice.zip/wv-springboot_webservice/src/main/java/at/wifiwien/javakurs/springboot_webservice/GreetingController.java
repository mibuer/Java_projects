package at.wifiwien.javakurs.springboot_webservice;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class GreetingController {

	
	//1. Endpunkt
	@GetMapping ("/greeting")
	public String greeting(@RequestParam final String word) {
		
		System.out.println("In Methode greeting der Klasse GreetingController: " + word);
		
		return word  + " World!";
			
	}
	
	//2.Endpunkt
	@GetMapping ("/greeting/{word}/")
	public String greetingHello(@PathVariable final String word) {
		
		System.out.println("In Methode greetingHello der Klasse GreetingController: " + word);
		
		return word + " World!";
	}
	
	//3.Endpunkt
	@PostMapping("/greeting/post")
	public String greetingPayload(final String word) {
		
		System.out.println("In Methode greetingPayload der Klasse GreetingController: " + word);
		
		return word + " World";
	}
	
	
	
}
