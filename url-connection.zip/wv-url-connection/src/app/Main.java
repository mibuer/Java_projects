package app;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;
import java.util.HashMap;
import java.util.Map;

public class Main {

	public static void main(String[] args) throws MalformedURLException, IOException {
		
		//Verbinden mit Webservice
		//http://localhost:8080/greeting
		
		//GET als PathVariable
		URLConnection con = new URL("http://localhost:8080/greeting?word=Hi").openConnection();
		
		BufferedReader reader = new BufferedReader(new InputStreamReader(con.getInputStream()));
		
		System.out.println(reader.readLine());
		
		reader.close();
		
		//GET mit RequestParameter
		URLConnection con2 = new URL("http://localhost:8080/greeting/Hello/").openConnection();
		
		BufferedReader reader2 = new BufferedReader(new InputStreamReader(con2.getInputStream()));
		
		System.out.println(reader2.readLine());
		
		reader.close();
		
		//POST mit Payload
		HttpURLConnection con3 = (HttpURLConnection) new URL("http://localhost:8080/greeting/").openConnection();
		
		con3.setRequestMethod("POST");
		con3.setDoOutput(true);
		
		Map<String, String> param = new HashMap<>();
		param.put("greeting", "Good Morning");
		
		String paramUTF8String = ParameterStringBuilder.getParamsString(param);
		System.out.println(paramUTF8String);
		
		DataOutputStream out = new DataOutputStream(con3.getOutputStream());
		
		out.writeBytes(paramUTF8String);
		out.flush();
		out.close();
		
		int status = con3.getResponseCode();
		System.out.println("Status: " + status);
		
		
		
		
	}

}
