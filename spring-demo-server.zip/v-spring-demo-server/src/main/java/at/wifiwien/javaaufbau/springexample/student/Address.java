package at.wifiwien.javaaufbau.springexample.student;

public record Address(String streetName, String streetNr) {}
