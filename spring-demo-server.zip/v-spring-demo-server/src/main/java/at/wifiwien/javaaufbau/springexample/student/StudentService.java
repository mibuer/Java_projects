package at.wifiwien.javaaufbau.springexample.student;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

@Service
public class StudentService {

	private static long nextId = 1L;
	private static List<Student> students = new ArrayList<>();
	
	public Student create(Student student) {
		
		return addStudent(student);
	}

	private static Student addStudent(Student student) {
		
		Student newStudent = new Student(nextId++, student.firstName(), student.lastName(), student.number(), student.adress());
		students.add(newStudent);
		return newStudent;
	}

	public List<Student> readAll() {
		
		return students;
	}
}
