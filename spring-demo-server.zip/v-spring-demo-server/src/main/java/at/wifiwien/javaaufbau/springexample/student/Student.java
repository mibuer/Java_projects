package at.wifiwien.javaaufbau.springexample.student;

public record Student(long id, String firstName, String lastName, String number, Address adress) {};

