package at.wifiwien.javaaufbau.springexample.customer;

public record Customer(String name, String job) {}
