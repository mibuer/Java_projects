package at.wifiwien.javaaufbau.hello;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

// Annotation damit dieser Controller tatsächlich erstellt wird.
@RestController
public class HelloController {

	private static final Logger logger = LoggerFactory.getLogger(HelloController.class);
	
	
	@GetMapping
	public String hello() {
		return "Hello World";
	}
	
	// 1. Endpoint
	// Reagiert auf Anfragen mit GET
	@GetMapping("/hello")
	public String helloWorld(@RequestParam final String name) {
	
		logger.info("Request Param: " + name);
		// Response
		return "Hello " + name + " (as RequestParam)";
	}
	
	
	// 2. Endpoint
	// Reagiert auf Anfragen mit GET
	@GetMapping("/hello/{name}/")
	public String helloName(@PathVariable final String name) {
		
		logger.info("Path variable: " + name);
		// Response
		return "Hello " + name + " (as PathVariable)";
	}
	
	// 3. Endpoint
	// Reagiert auf Anfragen mit POST
	@PostMapping("/hello")
	public String helloPayload(final String name) {
		
		logger.info("Payload: " + name);
		// Response
		return "Hello " + name + " (as Payload)";
	}
	
}
