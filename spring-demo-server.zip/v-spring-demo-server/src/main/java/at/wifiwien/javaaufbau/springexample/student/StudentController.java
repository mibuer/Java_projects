package at.wifiwien.javaaufbau.springexample.student;

import java.net.URI;
import java.net.URISyntaxException;
import java.util.List;

import org.apache.tomcat.jni.Address;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

@RestController
public class StudentController {

	private static final Logger logger = LoggerFactory.getLogger(StudentController.class);  
			
	private StudentService service;

	public StudentController(StudentService service) {
		this.service = service;
	}

	

	@PostMapping("/api/student/")
	public ResponseEntity<Student> create(@RequestBody Student student) throws URISyntaxException {
		
		logger.debug("Student: " + student + " received");
	    Student createdStudent = service.create(student);
	    if (createdStudent == null) {
	        return ResponseEntity.notFound().build();
	    } else {
	        URI uri = ServletUriComponentsBuilder.fromCurrentRequest()
	        									.path("/{id}")
	        									.buildAndExpand(createdStudent.id())
	        									.toUri();

	        return ResponseEntity.created(uri)
	          .body(createdStudent);
	    }
//	    return String.valueOf(createdStudent.id());
	}
	
	@GetMapping("/api/students/")
	public ResponseEntity<List<Student>> allStudents() {
		
		List<Student> students = service.readAll();
		return ResponseEntity.accepted().body(students);
		
	}

}
