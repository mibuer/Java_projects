module at.wifiwien_javaaufbau.w_calculator {
    requires javafx.controls;
    requires javafx.fxml;
    requires transitive javafx.graphics;

    opens at.wifiwien_javaaufbau.w_calculator to javafx.fxml;
    exports at.wifiwien_javaaufbau.w_calculator;
}
