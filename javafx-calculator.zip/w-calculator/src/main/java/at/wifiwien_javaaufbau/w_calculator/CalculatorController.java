package at.wifiwien_javaaufbau.w_calculator;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class CalculatorController {

    @FXML
    private Label displayLabel;
    
    private boolean enteringANumber = false;
    
    private CalculatorBrain calculatorBrain = new CalculatorBrain();
    
    
    //Controller enthält Eventhandler. Das Sind MEthoden, die aufgerufen werden sobald ein Event eintritt
    //zB das "Click" Event vom Button, ActionEvent
    //Immer wenn Butten gedrückt wird wird diese MEthode aufgerufen
    @FXML
    void onNumberClick(ActionEvent event) {

    	//Idee: im Display anzeigen welche Taste gedrückt wurde
    	
    	//Events enthalten Informationen über die eventSource (zB Button)
    	Button button = (Button) event.getSource();
    	//Auf die Attribute des Buttons kann man zugreifen/sie verwenden
    	String numberEntered = button.getText();
    	
    	String numberDisplayed = displayLabel.getText();
    	
    	//nur ein Komma darf eingegeben werden
    	if(numberEntered.equals(".") && numberDisplayed.contains(".")) {
    			numberEntered = "";
    	}
    	
    	//oder mit Regex überprüfen: "\\d+,\\d+"
    	
    	
    	if(enteringANumber) {
    		numberDisplayed += numberEntered;
    	} else {
    		numberDisplayed = numberEntered;
    		enteringANumber = true;
    	}
    	
    	displayLabel.setText(numberDisplayed);
    	
    }

    @FXML
    void onOperationClick(ActionEvent event) {
    	
    	Button button = (Button) event.getSource();
    	String operatorString = button.getText();
    	
    	//Idee: 1. Operand speichern, Operator speichern, auf 2. Operand warten 
    	calculatorBrain.setOperandString(displayLabel.getText());
    	try {
			calculatorBrain.setOperatorAsString(operatorString);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	if(operatorString.equals("=")) {
    	displayLabel.setText(calculatorBrain.getResultString());
    	}
    	
    	//wenn operator eingegeben, kommt eine neueZahl
    	enteringANumber = false;

    }

}
