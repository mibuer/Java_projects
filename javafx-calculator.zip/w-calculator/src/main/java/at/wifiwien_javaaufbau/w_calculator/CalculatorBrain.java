package at.wifiwien_javaaufbau.w_calculator;

import java.util.function.BinaryOperator;

public class CalculatorBrain {

	private static final BinaryOperator<Double> add = (op1, op2) -> op1 + op2;
	private static final BinaryOperator<Double> sub = (op1, op2) -> op1 - op2;
	private static final BinaryOperator<Double> mul = (op1, op2) -> op1 * op2;
	private static final BinaryOperator<Double> div = (op1, op2) -> op1 / op2;

	// Idee: merke Operand1, Operator und später Operand2, und =
	private String operandString;
	private String resultString;

	private double operand1;
	private double operand2;
	private BinaryOperator<Double> operator;

	public void setOperatorAsString(String operatorString) throws Exception {

		if (operatorString.equals("=")) {

			// operandString --> operand2
			
			operand2 = Double.parseDouble(operandString);
			
			//Ergebnis berechnen
			double result = operator.apply(operand1, operand2);
			
			//Ergebnis als STring verfügbar machen
			setResultString(String.valueOf(result));	
			
		} else {

			// switch expression: sie liefert ein Ergebnis, das ich einer Variable zuweisen
			// kann!
			// UND Feature: das "break" ist automatisch, d.h. kein Falltrough
			operator = switch (operatorString) {
			case "+" -> add;
			case "-" -> sub;
			case "*" -> mul;
			case "/" -> div;
			default -> throw new Exception("unknown operator");
			};
			
			// operand --> operand1
			operand1 = Double.parseDouble(operandString);
			
		}
		// switch statement
		/*
		 * switch(operatorString) { case "+": operator = add; break; case "-": operator
		 * = sub; break; case "*": operator = mul; break; case "/": operator = div;
		 * default: throw new Exception("Unknown Operator"); }
		 */

	}

	public String getOperandString() {
		return operandString;
	}

	public void setOperandString(String operandString) {
		this.operandString = operandString;
	}

	public String getResultString() {
		return resultString;
	}

	public void setResultString(String resultString) {
		this.resultString = resultString;
	}

}
